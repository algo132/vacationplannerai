my-dynamic-website/
|-- app/
|   |-- templates/
|   |   |-- index.html
|-- static/
|   |-- css/
|   |   |-- style.css
|-- functions/
|   |-- main.py
|   |-- requirements.txt
|-- public/
|-- .firebaserc
|-- firebase.json
